const discord = require("discord.js");
const db = require("quick.db");
const ayar = require("../settings.json");
let selamlar = ["sa", "selam", "selamın aleyküm", "selamın aleykum", "sea", "sA", "selamın aleykm", "selamün aleyküm", "selamun aleykum"]
module.exports = (message) => {
    if (message.author.bot) return;
    if (selamlar.some(s => message.content.toLowerCase() === s)) {
        message.channel.send(`${message.author}, Aleyküm selam hoş geldin.`)
    }
};

module.exports.configuration = {
    name: "message"
};