# Cross-Moderation-Bot
V12 Moderasyon Bot altyapısı settings.json doldurup terminale npm i yazın
